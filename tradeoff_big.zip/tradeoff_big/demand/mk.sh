#! /bin/bash

for ((i=1;i<=100;i=i+1))

do
	mkdir $i
done
